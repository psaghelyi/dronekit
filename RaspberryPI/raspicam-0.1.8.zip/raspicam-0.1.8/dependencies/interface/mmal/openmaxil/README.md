Please note that this wrapper layer has never been used in anger,
and this is NOT used by the firmware.

It was written with the intent of removing native OpenMaxIL support
from a platform, but that never happened and is not relevant to the
Raspberry Pi.

Please consider that these files are deprecated. They are maintained
here in case others are using them, but it is strongly recommended
that they are not used for new projects.
